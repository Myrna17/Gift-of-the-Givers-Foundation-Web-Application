﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using APPR.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APPR.Controllers.YourProjectName.Controllers.Tests;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using APPR.Controllers.YourProjectName.Controllers;

namespace APPR.Controllers.Tests
{
    [TestClass()]
    public class TasksControllerTests
    {
        // This method will run before each test to set up an in memory database
        private object _controller;
        private object _context;
        private object httpsContext;

        public TasksController Controller { get; private set; }

        [TestInitialize]
        public void Setup()
        {
            //set up in memory database fot testing
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "appr")
                .Options;



            _context = new ApplicationDbContext(options) { };


            //Mock IHttpsContext
            var _httpContextAccessor = new Mock<IHttpContextAccessor>();

            // Mock HttpContext and sessions
            var httpContext = new DefaultHttpContext();
            httpsContext.Session = new Mock<ISession>().Object;
            _httpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            //initalize the account with in memory context and mock httpContext( only add if you using this)
            Controller = new YourProjectName.Controllers.VolunteersController(_context, _httpContextAccessor.Object);


        }
        [TestMethod]
        public async Task PutDonationTest_Fail_emailAlreadyExits()
        {
            var existingUser = new User
            {
                FirstName = "John",
                LastName = "Joe",
                Email = "jj@gmail.com",
                Password = "password",
                Role = "Volunteer"

            };
            // Add and existing user in the  memory database
            _context.User.Add(existingUser);
            object value = await _context.SaveChangesAsync();

            var model = new RegisterViewModel
            {

                FirtName = "Jane",
                LastName = "Joe",
                Email = "jj@gmail.com",
                Password = "password",
                Role = "Volunteer"
            };

            //Act
            var result = await _controller.RegisterAsync(model);

            //Assert

            Xunit.Assert.NotNull(result.Succeeded);


        }
        [TestMethod]
        public async Task Resgister_Successful()
        {


            var model = new RegisterViewModel
            {

                FirtName = "William",
                LastName = "Willis",
                Email = "ww@gmail.com",
                Password = "password12",
                Role = "Volunteer"
            };

            //Act
            var result = await _controller.RegisterAsync(model);

            //Assert

            Xunit.Assert.True(result.Succeeded);


        }
    }
}