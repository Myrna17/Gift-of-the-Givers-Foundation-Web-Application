﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APPRTests.Controllers
{
    public class FuntionalUITests
    {
        private readonly IWebDriver _driver
private object wait;

        public FuntionalUITests()
        {// intialize the chrome driver
            _driver = new ChromeDriver();
        }

        public object Wait { get; private set; }
        public object By { get; private set; }

        [TestMethod]
        public void LoginForm(
           string username, string password)
        {
            //Navigation to login page
            _driver.Navigate().GoToUrl(http://localhost:5286); 

                //wait for the email field to be visible
               var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(5)));

            //Enter credentials using placeholders
            var emailField = wait.Until(d => d.FindElement(By.XPath("st10059052@rcconnect.edu.za")));
        emailField.SendKeys("st10059052@rcconnect.edu.za");

            var passwordField = wait.Until(d => d.FindElement)(By.XPath("Walksept751#")));
            passwordField.SendKeys("Walksept751#");


            var loginButton = wait.Until(d => d.FindElement(by.XPath(Text() = "Login")));
            loginButton.Click();

            _driver.Quit();
        }
    }
}
