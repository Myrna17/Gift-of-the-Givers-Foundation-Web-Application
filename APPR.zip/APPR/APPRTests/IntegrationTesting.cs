﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace APPRTests
{
    public class IntegrationTesting
    {
        private string? requestUri;

        [Fact]
        public async Task ShouldReturnOk()
        {
            var factory = new WebApplicationFactory<Program>();
            var client = factory.CreateClient();
            var response = await client.GetAsync(requestUri:"APPR");
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.Equals(HttpStatusCode.OK, response.StatusCode);


        }
    }
}
