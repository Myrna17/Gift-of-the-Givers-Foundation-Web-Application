﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace APPR.Controllers
{
    public class StartupController : Controller
    { }
        private readonly object JwtBearerDefaults;

        public void ConfigureServices(IServiceCollection services)
        {
            // Configure Entity Framework
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer( // Replace with your connection string
                    Configuration.GetConnectionString("DefaultConnection")));

            // Add Identity services with appropriate user and role types
            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();

            // Configure Authentication using Azure Active Directory (AAD)
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.Authority = $"https://login.microsoftonline.com/{Configuration["AzureAd:TenantId"]}"; // Use configuration for Tenant ID
                options.Audience = Configuration["AzureAd:Audience"]; // Use configuration for Audience

                // Enable validation for a more secure production environment
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    IssuerSigningKey = new SymmetricSecurityKey( // Use a secure key for validation
                        Encoding.ASCII.GetBytes(Configuration["AzureAd:SigningKey"]))
                };
            });

            // Add services for your application features (e.g., email, logging)
            services.AddControllersWithViews(); 
          
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
