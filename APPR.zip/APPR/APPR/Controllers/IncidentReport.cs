﻿namespace APPR.Controllers
{
    public class IncidentReport
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        
    }
}
