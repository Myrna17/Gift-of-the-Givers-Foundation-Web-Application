﻿namespace APPR.Controllers
{
    public class Donation
    {
        public int Id { get; set; }
        public string ResourceType { get; set; }
        public int Quantity { get; set; }
        
    }
}
