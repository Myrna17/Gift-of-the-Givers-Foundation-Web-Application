﻿using Microsoft.AspNetCore.Mvc;

namespace APPR.Controllers
{
    public class DonationsController : Controller
    { } namespace YourProjectName.Controllers
    {
        [ApiController]
        [Route("api/[controller]")]
        public class DonationsController(object _context, ApplicationDbContext context) : ControllerBase
        {
            private readonly ApplicationDbContext _context = context;
            private object context;
            private IHttpContextAccessor @object;

            public DonationsController(object context, IHttpContextAccessor @object)
            {
                this.context = context;
                this.@object = @object;
            }

            public object EntityState { get; private set; }

            // GET:   

            [HttpGet]
            public async Task<ActionResult<IEnumerable<Donation>>> GetDonations()
            {
                return await _context.Donations.ToListAsync();
            }

            // GET: api/Donations/5
            [HttpGet("{id}")]
            public async Task<ActionResult<Donation>> GetDonation(int id)
            {
                var donation
     = await _context.Donations.FindAsync(id);

                if (donation == null)
                {
                    return NotFound();
                }

                return donation;
            }

            // POST: api/Donations   

            [HttpPost]
            public async Task<ActionResult<Donation>> PostDonation(Donation donation)
            {
                _context.Donations.Add(donation);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetDonation", new
                {
                    id = donation.Id
                }, donation);
            }

            // PUT: api/Donations/5
            [HttpPut("{id}")]
            public async Task<IActionResult> PutDonation(int id, Donation donation)
            {
                if (id != donation.Id)
                {
                    return BadRequest();
                }

                _context.Entry(donation).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)

                {
                    if (!DonationExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();
            }

            // DELETE: api/Donations/5
            [HttpDelete("{id}")]
            public async Task<IActionResult> DeleteDonation(int
     id)
            {
                var donation = await _context.Donations.FindAsync(id);
                if (donation == null)
                {
                    return NotFound();
                }

                _context.Donations.Remove(donation);
                await _context.SaveChangesAsync();

                return NoContent();
            }

            private bool DonationExists(int id)
            {
                return _context.Donations.Any(e => e.Id == id);

            }
        }
    }
    [HttpPost]
        public IActionResult MakeDonation([FromBody] Donation donation)
        {
            // Validate and save the donation to the database
            return Ok();
        }

    private IActionResult Ok()
    {
        throw new NotImplementedException();
    }

    public IActionResult Index()
        {
            return ViewResult();
        }

    private IActionResult View()
    {
        throw new NotImplementedException();
    }
}

