﻿namespace APPR.Controllers
{
    internal class ApplicationUser
    {
    }
}