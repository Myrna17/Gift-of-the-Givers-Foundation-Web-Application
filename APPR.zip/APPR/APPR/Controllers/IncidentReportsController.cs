﻿using Microsoft.AspNetCore.Mvc;

namespace APPR.Controllers
{
    public class TasksController : Controller
    { } namespace YourProjectName.Controllers
    {
        [ApiController]
        [Route("api/[controller]")]
        public class VolunteersController : ControllerBase
        {
            private readonly ApplicationDbContext _context;
            private object context;
            private IHttpContextAccessor @object;

            public object EntityState { get; private set; }

            public VolunteersController(ApplicationDbContext context)
            {
                _context = context;
            }

            public VolunteersController(object context, IHttpContextAccessor @object)
            {
                this.context = context;
                this.@object = @object;
            }

            // GET: api/IncidentReports
            [HttpGet]
            public async Task<ActionResult<IEnumerable<IncidentReport>>> GetIncidentReports()
            {
                return await _context.IncidentReports.ToListAsync();
            }

            // GET: api/IncidentReports/5
            [HttpGet("{id}")]
            public async Task<ActionResult<IncidentReport>> GetIncidentReport(int id)
            {
                var incidentReport = await _context.IncidentReports.FindAsync(id);

                if (incidentReport == null)
                {
                    return NotFound();
                }

                return incidentReport;
            }

            // POST:   
           
                   [HttpPost]
            public async Task<ActionResult<IncidentReport>> PostIncidentReport(IncidentReport incidentReport)
            {
                _context.IncidentReports.Add(incidentReport);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetIncidentReport", new { id = incidentReport.Id }, incidentReport);
            }

            // PUT: api/IncidentReports/5
            [HttpPut("{id}")]
            public async Task<IActionResult> PutIncidentReport(int id, IncidentReport incidentReport)
            {
                if (id != incidentReport.Id)
                {
                    return BadRequest();
                }

                _context.Entry(incidentReport).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IncidentReportExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();

            }

            // DELETE: api/IncidentReports/5
            [HttpDelete("{id}")]
            public async Task<IActionResult> DeleteIncidentReport(int id)
            {
                var incidentReport = await _context.IncidentReports.FindAsync(id);
                if (incidentReport == null)
                {
                    return NotFound();
                }

                _context.IncidentReports.Remove(incidentReport);
                await _context.SaveChangesAsync();

                return
     NoContent();
            }

            private bool IncidentReportExists(int
     id)
            {
                return _context.IncidentReports.Any(e => e.Id == id);
            }
        }
    }
    [HttpPost]
        public IActionResult ReportIncident([FromBody] IncidentReport report)
        {
            // Validate and save the report to the database
            return Ok();
        }
        public IActionResult Index()
        {
            return View();
        }
    }

