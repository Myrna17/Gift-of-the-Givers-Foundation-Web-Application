﻿using APPR.Controllers.YourProjectName.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace APPR.Controllers
{
    public class TasksController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public static implicit operator TasksController(VolunteersController v)
        {
            throw new NotImplementedException();
        }
    }
}
