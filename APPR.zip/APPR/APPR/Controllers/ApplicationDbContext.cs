﻿
namespace APPR.Controllers
{
    internal class ApplicationDbContext
    {
        private object options;

        public ApplicationDbContext(object options)
        {
            this.options = options;
        }

        public object Volunteers { get; internal set; }
        public object Donations { get; internal set; }
        public object IncidentReports { get; internal set; }

        internal object Entry(Donation donation)
        {
            throw new NotImplementedException();
        }

        internal object Entry(IncidentReport incidentReport)
        {
            throw new NotImplementedException();
        }

        internal Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }
    }
}