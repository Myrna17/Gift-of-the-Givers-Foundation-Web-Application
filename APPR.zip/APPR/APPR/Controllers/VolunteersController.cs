﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Security.Claims;

namespace APPR.Controllers
{
    public class VolunteersController : Controller
    { }
        namespace YourProjectName.Controllers
    {
        [ApiController]
        [Route("api/[controller]")]
        public class VolunteersController(ApplicationDbContext context) : ControllerBase
        {
            private readonly ApplicationDbContext _context = context;

            // GET:   

            [HttpGet]
            public async Task<ActionResult<IEnumerable<Volunteer>>> GetVolunteers()
            {
                return await _context.Volunteers.ToListAsync();
            }

            // GET: api/Volunteers/5
            [HttpGet("{id}")]
            public async Task<ActionResult<Volunteer>> GetVolunteer(int
     id)
            {
                var volunteer = await _context.Volunteers.FindAsync(id);

                if (volunteer == null)
                {
                    return NotFound();
                }

                return volunteer;

            }

            // POST: api/Volunteers
            [HttpPost]
            public async Task<ActionResult<Volunteer>> PostVolunteer(Volunteer volunteer)
            {
                _context.Volunteers.Add(volunteer);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetVolunteer", new
                {
                    id = volunteer.Id
                }, volunteer);
            }

            // PUT: api/Volunteers/5
            [HttpPut("{id}")]
            public async Task<IActionResult> PutVolunteer(int id, Volunteer volunteer)
            {
                if (id != volunteer.Id)
                {
                    return BadRequest();
                }

                _context.Entry(volunteer).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VolunteerExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();
            }

            // DELETE: api/Volunteers/5   

            [HttpDelete("{id}")]
            public async Task<IActionResult> DeleteVolunteer(int id)
            {
                var volunteer = await _context.Volunteers.FindAsync(id);
                if (volunteer == null)
                {
                    return NotFound();
                }

                _context.Volunteers.Remove(volunteer);
                await _context.SaveChangesAsync();

                return
     NoContent();
            }

            private bool VolunteerExists(int id)
            {
                return _context.Volunteers.Any(e => e.Id
     == id);
            }

            public override bool Equals(object? obj)
            {
                return obj is VolunteersController controller &&
                       EqualityComparer<HttpContext>.Default.Equals(HttpContext, controller.HttpContext) &&
                       EqualityComparer<HttpRequest>.Default.Equals(Request, controller.Request) &&
                       EqualityComparer<HttpResponse>.Default.Equals(Response, controller.Response) &&
                       EqualityComparer<RouteData>.Default.Equals(RouteData, controller.RouteData) &&
                       EqualityComparer<ModelStateDictionary>.Default.Equals(ModelState, controller.ModelState) &&
                       EqualityComparer<ControllerContext>.Default.Equals(ControllerContext, controller.ControllerContext) &&
                       EqualityComparer<IModelMetadataProvider>.Default.Equals(MetadataProvider, controller.MetadataProvider) &&
                       EqualityComparer<IModelBinderFactory>.Default.Equals(ModelBinderFactory, controller.ModelBinderFactory) &&
                       EqualityComparer<IUrlHelper>.Default.Equals(Url, controller.Url) &&
                       EqualityComparer<IObjectModelValidator>.Default.Equals(ObjectValidator, controller.ObjectValidator) &&
                       EqualityComparer<ProblemDetailsFactory>.Default.Equals(ProblemDetailsFactory, controller.ProblemDetailsFactory) &&
                       EqualityComparer<ClaimsPrincipal>.Default.Equals(User, controller.User) &&
                       EqualityComparer<ApplicationDbContext>.Default.Equals(_context, controller._context);
            }

            public override int GetHashCode()
            {
                throw new NotImplementedException();
            }
        }
    }
    [HttpPost]
        public IActionResult RegisterVolunteer([FromBody] Volunteer volunteer)
        {
            // Validate and save the volunteer to the database
            return Ok();
        }
        public IActionResult Index()
        {
            return PartialViewResult();
        }

    private IActionResult PartialViewResult()
    {
        throw new NotImplementedException();
    }
}

